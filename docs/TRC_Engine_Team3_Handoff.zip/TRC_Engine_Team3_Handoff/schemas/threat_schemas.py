"""
agents/threat_agent/schemas.py
ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°
TRC Engine ÃŽâ€œÃƒâ€¡ÃƒÂ¶ Phase 1: Threat Agent  |  Data Contract (Day-1 Freeze)
ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡
This module is the **single source of truth** for every data shape flowing
through the Threat Agent.  All other modules (retrieval, attack_chain,
generator, scorer, validator, router) import from here ÃŽâ€œÃƒâ€¡ÃƒÂ¶ never the reverse.

Design principles enforced here
ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡
ÃŽâ€œÃƒâ€¡ÃƒÂ³ Clean Architecture  ÃŽâ€œÃƒâ€¡ÃƒÂ´ every inter-module boundary is a Pydantic model.  # noqa: RUF002
ÃŽâ€œÃƒâ€¡ÃƒÂ³ Type Safety         ÃŽâ€œÃƒâ€¡ÃƒÂ´ full annotations; no `Any` except where semantically  # noqa: RUF002
                        required and explicitly justified via a comment.
ÃŽâ€œÃƒâ€¡ÃƒÂ³ Immutability        ÃŽâ€œÃƒâ€¡ÃƒÂ´ all models are frozen after construction  # noqa: RUF002
                        (`model_config = ConfigDict(frozen=True)`).
ÃŽâ€œÃƒâ€¡ÃƒÂ³ Explicitness        ÃŽâ€œÃƒâ€¡ÃƒÂ´ every field carries a `Field(description=ÃŽâ€œÃƒâ€¡Ã‚Âª)` string  # noqa: RUF002
                        so the schema is self-documenting and IDE-friendly.
ÃŽâ€œÃƒâ€¡ÃƒÂ³ Validation-on-load  ÃŽâ€œÃƒâ€¡ÃƒÂ´ range checks, pattern checks, and enum constraints  # noqa: RUF002
                        are enforced by Pydantic at instantiation time, not
                        sprinkled ad-hoc across business logic.

SCRP Loop mapping (Section 2.2 of Phase1_Threat_Agent_Build_Plan_v4.md)
ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡
  Perceive  ÃŽâ€œÃƒÂ¥Ãƒâ€   ThreatAgentInput  ÃŽâ€œÃƒÂ¥Ãƒâ€   NormalizedInput
  Plan      ÃŽâ€œÃƒÂ¥Ãƒâ€   RetrievalPlan
  Act/Fetch ÃŽâ€œÃƒÂ¥Ãƒâ€   KBCandidate
  Chain     ÃŽâ€œÃƒÂ¥Ãƒâ€   AttackPath
  Observe   ÃŽâ€œÃƒÂ¥Ãƒâ€   ThreatScenario  (carries EvidenceChain + confidence_score)
  Validate  ÃŽâ€œÃƒÂ¥Ãƒâ€   ValidationResult
  Produce   ÃŽâ€œÃƒÂ¥Ãƒâ€   SCRSWriteResult

All imports that external modules need:

    from agents.threat_agent.schemas import (
        EvidenceChain,
        ThreatScenario,
        ValidationResult,
        AttackPath,
        KBCandidate,
        ThreatAgentInput,
        NormalizedInput,
        RetrievalPlan,
        SCRSWriteResult,
        STRIDECategory,
        ThreatStatus,
        KBSource,
    )

Ruff compliance
ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡
ÃŽâ€œÃƒâ€¡ÃƒÂ³ Line length  ÃŽâ€œÃƒÂ«ÃƒÂ± 88 chars (ruff default).
ÃŽâ€œÃƒâ€¡ÃƒÂ³ No unused imports.
ÃŽâ€œÃƒâ€¡ÃƒÂ³ No mutable default arguments (use `default_factory`).
ÃŽâ€œÃƒâ€¡ÃƒÂ³ String annotations are *not* used (Python 3.11+ runtime evaluation is fine).
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from enum import StrEnum
from typing import Annotated

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

# ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°
# Ã¢â€Â¬Ã‚Âº 0  ÃŽâ€œÃƒâ€¡ÃƒÂ¶  Enumerations  (stable, version-controlled vocabulary)
# ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°


class STRIDECategory(StrEnum):
    """STRIDE threat-category taxonomy.

    Each value corresponds to one of the six canonical STRIDE classes defined
    in Microsoft's threat-modelling methodology.  Using a typed enum instead of
    a raw string prevents generator / validator divergence at the schema level.
    """

    SPOOFING = "Spoofing"
    TAMPERING = "Tampering"
    REPUDIATION = "Repudiation"
    INFORMATION_DISCLOSURE = "InformationDisclosure"
    DENIAL_OF_SERVICE = "DenialOfService"
    ELEVATION_OF_PRIVILEGE = "ElevationOfPrivilege"


class ThreatStatus(StrEnum):
    """Lifecycle state of a ThreatScenario.

    State transitions (enforced by validator.py / router.py ÃŽâ€œÃƒâ€¡ÃƒÂ¶ not here):

        pending_test  ÃŽâ€œÃƒÂ¥Ãƒâ€   pending_human  (Protocol Invariant Validator passed)
                      ÃŽâ€œÃƒÂ¥ÃƒÂ¿  pending_test   (retry, max 3 times)
        pending_human ÃŽâ€œÃƒÂ¥Ãƒâ€   approved       (human approves)
                      ÃŽâ€œÃƒÂ¥Ãƒâ€   rejected       (human rejects ÃŽâ€œÃƒÂ¥Ãƒâ€  retry or escalate)
    """

    PENDING_TEST = "pending_test"
    PENDING_HUMAN = "pending_human"
    APPROVED = "approved"
    REJECTED = "rejected"


class KBSource(StrEnum):
    """Knowledge-base provenance tags.

    Identifies which threat-intelligence database a KBCandidate was drawn
    from.  Kept as an enum so retrieval.py, attack_chain.py, and scorer.py
    can branch deterministically without string matching.
    """

    STRIDE = "STRIDE"
    CAPEC = "CAPEC"
    ATT_AND_CK = "ATT&CK"
    CWE = "CWE"


# ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°
# Ã¢â€Â¬Ã‚Âº 1  ÃŽâ€œÃƒâ€¡ÃƒÂ¶  EvidenceChain
#         (core explainability unit ÃŽâ€œÃƒâ€¡ÃƒÂ¶ one per ThreatScenario)
# ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°


class EvidenceChain(BaseModel):
    """Structured evidence linking a KB pattern to a specific asset.

    This model is the explainability backbone of every ThreatScenario.
    The validator (validator.py) checks each field individually for
    non-emptiness and non-genericity before allowing a scenario to advance
    from ``pending_test`` to ``pending_human``.

    Evidence-completeness score (used by scorer.py ÃŽâ€œÃƒâ€¡ÃƒÂ¶ Section 2.6):
        +1.0  all three prose fields are non-empty and non-generic
        +0.5  one field is empty or flagged as generic
        +0.0  two or more fields fail the completeness check
    """

    model_config = ConfigDict(frozen=True, populate_by_name=True)

    exposure: Annotated[
        str,
        Field(
            min_length=1,
            description=(
                "The concrete asset attribute, configuration, or interface "
                "property that creates the attack surface.  Must reference a "
                "real field from the system model ÃŽâ€œÃƒâ€¡ÃƒÂ¶ not a generic placeholder "
                "such as 'unknown exposure' or 'N/A'."
            ),
        ),
    ]

    matched_pattern: Annotated[
        str,
        Field(
            min_length=1,
            description=(
                "The canonical KB pattern identifier that was matched to this "
                "exposure, e.g. 'CAPEC-94', 'ATT&CK T1190', 'CWE-306'.  "
                "Must resolve to a real entry in the KB store ÃŽâ€œÃƒâ€¡ÃƒÂ¶ validated "
                "by the Protocol Invariant Validator."
            ),
        ),
    ]

    applicability_reason: Annotated[
        str,
        Field(
            min_length=20,
            description=(
                "LLM-generated prose that explicitly explains WHY the matched "
                "pattern applies to this specific asset and exposure ÃŽâ€œÃƒâ€¡ÃƒÂ¶ not a "
                "generic restatement of the pattern description.  Minimum "
                "20 characters enforced to deter single-word placeholders; "
                "the Validator performs a deeper genericity check at runtime."
            ),
        ),
    ]

    citation: Annotated[
        str,
        Field(
            min_length=1,
            description=(
                "Human-readable citation for the KB entry, e.g.: "
                "'CAPEC-94: Adversary in the Middle (CAPEC v3.9)' or "
                "'MITRE ATT&CK T1190: Exploit Public-Facing Application "
                "(v14.1)'.  Must be non-empty; used by the human reviewer "
                "to verify the evidence without accessing the raw KB."
            ),
        ),
    ]


# ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°
# Ã¢â€Â¬Ã‚Âº 2  ÃŽâ€œÃƒâ€¡ÃƒÂ¶  ThreatScenario
#         (primary output unit of the Threat Agent)
# ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°


# Confidence score type alias ÃŽâ€œÃƒâ€¡ÃƒÂ¶ self-documenting at call sites
ConfidenceScore = Annotated[
    float,
    Field(
        ge=0.0,
        le=1.0,
        description=(
            "Weighted confidence score ÃŽâ€œÃƒÂªÃƒÂª [0.0, 1.0] computed per the "
            "Section 2.6 formula:\n"
            "  0.4 Ã¢â€Å“ÃƒÂ¹ retrieval_match_strength\n"
            "+ 0.4 Ã¢â€Å“ÃƒÂ¹ self_consistency\n"
            "+ 0.2 Ã¢â€Å“ÃƒÂ¹ evidence_completeness\n"
            "Scores below 0.4 are considered low-confidence and will trigger "
            "a validator warning (not an automatic rejection)."
        ),
    ),
]


class ThreatScenario(BaseModel):
    """A fully structured, evidence-backed threat scenario.

    Produced by generator.py, scored by scorer.py, validated by validator.py,
    and written to the SCRS by state_manager.py after human approval.

    Lifecycle enforced externally (validator.py / router.py):
        pending_test  ÃŽâ€œÃƒÂ¥Ãƒâ€   [Validator pass]  ÃŽâ€œÃƒÂ¥Ãƒâ€   pending_human
        pending_human ÃŽâ€œÃƒÂ¥Ãƒâ€   [Human approve]   ÃŽâ€œÃƒÂ¥Ãƒâ€   approved
        pending_human ÃŽâ€œÃƒÂ¥Ãƒâ€   [Human reject]    ÃŽâ€œÃƒÂ¥Ãƒâ€   rejected (retry or escalate)
        pending_test  ÃŽâ€œÃƒÂ¥Ãƒâ€   [Validator fail]  ÃŽâ€œÃƒÂ¥Ãƒâ€   pending_test (retry ÃŽâ€œÃƒÂ«ÃƒÂ± 3 times)

    Immutability:
        The model is frozen.  State transitions are performed by producing a
        new instance via ``model.model_copy(update={"status": new_status})``.
    """

    model_config = ConfigDict(frozen=True, populate_by_name=True)

    tid: Annotated[
        str,
        Field(
            min_length=1,
            description=(
                "Unique threat identifier within this run.  Convention: "
                "'THR-<run_id>-<zero-padded sequence>', e.g. 'THR-abc123-001'. "
                "Generated by generator.py; immutable after creation."
            ),
        ),
    ]

    asset_id: Annotated[
        str,
        Field(
            min_length=1,
            description=(
                "Identifier of the system-model asset this scenario targets.  "
                "Must correspond to an asset declared in the originating "
                "ThreatAgentInput.system_model ÃŽâ€œÃƒâ€¡ÃƒÂ¶ validated by validator.py."
            ),
        ),
    ]

    stride_category: Annotated[
        STRIDECategory,
        Field(
            description=(
                "STRIDE classification of the threat.  Using the enum (not a "
                "raw string) ensures generator/validator agreement without "
                "string comparison."
            ),
        ),
    ]

    attack_vector: Annotated[
        str,
        Field(
            min_length=1,
            description=(
                "Human-readable description of the technical attack vector, "
                "e.g. 'Unauthenticated BLE advertisement replay' or "
                "'SQL injection via unvalidated REST query parameter'.  "
                "Must be specific to the asset ÃŽâ€œÃƒâ€¡ÃƒÂ¶ not a copy of the KB "
                "pattern title."
            ),
        ),
    ]

    kb_reference: Annotated[
        str,
        Field(
            min_length=1,
            description=(
                "Primary KB entry identifier this scenario is grounded in, "
                "e.g. 'CAPEC-94', 'ATT&CK T1190', 'CWE-306'.  "
                "The validator confirms this ID resolves to a real KB entry."
            ),
        ),
    ]

    evidence_chain: Annotated[
        EvidenceChain,
        Field(
            description=(
                "Structured evidence that links the KB pattern to the "
                "specific asset and explains applicability.  Required; "
                "a ThreatScenario without evidence is not permitted."
            ),
        ),
    ]

    confidence_score: ConfidenceScore

    status: Annotated[
        ThreatStatus,
        Field(
            default=ThreatStatus.PENDING_TEST,
            description=(
                "Lifecycle state.  Always starts as 'pending_test'; "
                "transitions are driven by validator.py and router.py, "
                "never mutated inside generator.py or scorer.py."
            ),
        ),
    ]

    # ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ derived / audit fields ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡ÃŽâ€œÃƒÂ¶Ãƒâ€¡

    created_at: Annotated[
        datetime,
        Field(
            default_factory=lambda: datetime.now(UTC),
            description="UTC timestamp of scenario creation (auto-set).",
        ),
    ]

    run_id: Annotated[
        str,
        Field(
            min_length=1,
            description=(
                "Identifier of the ThreatAgent run that produced this "
                "scenario.  Ties the scenario to its audit log entry in "
                "common/logging.py and to the SCRS write record."
            ),
        ),
    ]

    use_case_id: Annotated[
        str | None,
        Field(
            default=None,
            description="Traceability: id of the use case this scenario was generated for.",
        ),
    ] = None

    asset_version: Annotated[
        str | None,
        Field(
            default=None,
            description="Traceability: version of the asset record the scenario targets.",
        ),
    ] = None

    kb_snapshot_version: Annotated[
        str | None,
        Field(
            default=None,
            description="Traceability: KB snapshot version used for retrieval.",
        ),
    ] = None

    project_id: Annotated[
        str | None,
        Field(
            default=None,
            description=(
                "Traceability: the product/project this scenario belongs to. Together with "
                "use_case_id it identifies a use case when one product has several."
            ),
        ),
    ] = None

    asset_fingerprint: Annotated[
        str | None,
        Field(
            default=None,
            description=(
                "Traceability: short hash of the asset facts this threat was derived from. "
                "If the asset changes later, the threat is out of date (staleness check)."
            ),
        ),
    ] = None

    context_fingerprint: Annotated[
        str | None,
        Field(
            default=None,
            description=(
                "Traceability: short hash of the use-case text and system model used. "
                "A change means every threat of the use case may be out of date."
            ),
        ),
    ] = None

    validation_status: Annotated[
        str | None,
        Field(
            default=None,
            description=(
                "Validation outcome for this scenario: 'passed' when all invariant "
                "checks pass, or 'escalated_after_retries' when retry attempts were "
                "exhausted and human review was required."
            ),
        ),
    ] = None

    @field_validator("confidence_score", mode="before")
    @classmethod
    def _clamp_confidence(cls, v: float) -> float:
        """Hard-clamp before Pydantic's ge/le check for defensive safety.

        Rationale: floating-point arithmetic in scorer.py may produce values
        like 1.0000000000000002 due to IEEE 754 rounding.  Clamping here
        prevents spurious ValidationError while keeping the semantic range.
        """
        return max(0.0, min(1.0, float(v)))


# ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°
# Ã¢â€Â¬Ã‚Âº 3  ÃŽâ€œÃƒâ€¡ÃƒÂ¶  ValidationResult
#         (output of validator.py ÃŽâ€œÃƒâ€¡ÃƒÂ¶ drives retry logic)
# ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°


class FailedCheck(BaseModel):
    """A single failed invariant check from the Protocol Invariant Validator.

    Structured as its own model (not a bare ``str``) so that router.py and
    the retry loop can branch on ``check_id`` without parsing free text.
    """

    model_config = ConfigDict(frozen=True)

    check_id: Annotated[
        str,
        Field(
            min_length=1,
            description=(
                "Machine-readable identifier for the failed check, e.g. "
                "'CITATION_MISSING', 'CONFIDENCE_BELOW_THRESHOLD', "
                "'ASSET_REF_INVALID', 'EVIDENCE_GENERIC'."
            ),
        ),
    ]

    affected_tid: Annotated[
        str | None,
        Field(
            default=None,
            description=(
                "``tid`` of the ThreatScenario that triggered this failure, "
                "or ``None`` if the failure is batch-level (e.g. empty output)."
            ),
        ),
    ]

    detail: Annotated[
        str,
        Field(
            min_length=1,
            description=(
                "Human-readable explanation of why the check failed.  "
                "This text is passed verbatim as context to the retry prompt "
                "in generator.py ÃŽâ€œÃƒâ€¡ÃƒÂ¶ it must be actionable, not just a code."
            ),
        ),
    ]


class ValidationResult(BaseModel):
    """Outcome of one Protocol Invariant Validator execution.

    Consumed by:
    ÃŽâ€œÃƒâ€¡ÃƒÂ³ router.py   ÃŽâ€œÃƒâ€¡ÃƒÂ¶ to gate state transition from pending_test ÃŽâ€œÃƒÂ¥Ãƒâ€  pending_human
    ÃŽâ€œÃƒâ€¡ÃƒÂ³ generator.py ÃŽâ€œÃƒâ€¡ÃƒÂ¶ the ``detail`` strings in ``failed_checks`` are injected
                     into the retry prompt so the LLM understands what to fix.
    ÃŽâ€œÃƒâ€¡ÃƒÂ³ scorer.py   ÃŽâ€œÃƒâ€¡ÃƒÂ¶ ``passed`` and ``failed_checks`` inform the
                     evidence-completeness component of the confidence score.

    Retry-count contract (Section 2.2 / 2.6 of build plan):
        retry_count starts at 0 on the first validator call and increments by 1
        on each failure before the next LLM invocation.  At retry_count == 3
        the system must NOT call the LLM again; instead it escalates to human
        review as a *flagged* failure with status ``pending_human``.
    """

    model_config = ConfigDict(frozen=True)

    passed: Annotated[
        bool,
        Field(
            description=(
                "True iff every invariant check passed.  "
                "When False, ``failed_checks`` will be non-empty."
            ),
        ),
    ]

    failed_checks: Annotated[
        list[FailedCheck],
        Field(
            default_factory=list,
            description=(
                "Ordered list of invariant checks that failed.  Empty when "
                "``passed`` is True.  Each entry is a structured FailedCheck "
                "rather than a bare string so retry logic can branch "
                "programmatically on ``check_id``."
            ),
        ),
    ]

    retry_count: Annotated[
        int,
        Field(
            default=0,
            ge=0,
            le=3,
            description=(
                "Number of LLM retry attempts consumed so far for this "
                "validation cycle.  Strictly capped at 3 (le=3).  "
                "validator.py raises ``MaxRetriesExceededError`` if an "
                "attempt is made to increment beyond this limit."
            ),
        ),
    ]

    validated_at: Annotated[
        datetime,
        Field(
            default_factory=lambda: datetime.now(UTC),
            description="UTC timestamp of this validation run (auto-set).",
        ),
    ]

    @model_validator(mode="after")
    def _check_passed_consistency(self) -> ValidationResult:
        """Enforce semantic consistency between ``passed`` and ``failed_checks``.

        Invariants:
          ÃŽâ€œÃƒâ€¡ÃƒÂ³ passed=True  must imply failed_checks is empty.
          ÃŽâ€œÃƒâ€¡ÃƒÂ³ passed=False must imply failed_checks is non-empty.

        This prevents the silent ambiguity of a model reporting success while
        carrying failure details (or vice-versa), which would break retry logic.
        """
        if self.passed and self.failed_checks:
            raise ValueError(
                "ValidationResult is inconsistent: passed=True but "
                f"failed_checks is non-empty ({len(self.failed_checks)} items). "
                "Set passed=False or clear failed_checks."
            )
        if not self.passed and not self.failed_checks:
            raise ValueError(
                "ValidationResult is inconsistent: passed=False but "
                "failed_checks is empty.  Provide at least one FailedCheck "
                "so the retry loop has actionable context."
            )
        return self


# ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°
# Ã¢â€Â¬Ã‚Âº 4  ÃŽâ€œÃƒâ€¡ÃƒÂ¶  KBCandidate
#         (output of retrieval.py ÃŽâ€œÃƒâ€¡ÃƒÂ¶ input to attack_chain.py)
# ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°


class KBCandidate(BaseModel):
    """A single ranked KB pattern retrieved for a given asset attribute.

    Produced by retrieval.py (FAISS nearest-neighbour search) and consumed
    by attack_chain.py to build AttackPath objects, and by scorer.py to
    compute the retrieval_match_strength component of the confidence score.
    """

    model_config = ConfigDict(frozen=True)

    pattern_id: Annotated[
        str,
        Field(
            min_length=1,
            description=(
                "Canonical KB pattern identifier, e.g. 'CAPEC-94', "
                "'ATT&CK T1190', 'CWE-306'.  Must be unique within a "
                "retrieval result set for a given asset."
            ),
        ),
    ]

    source: Annotated[
        KBSource,
        Field(description="Knowledge-base provenance (STRIDE/CAPEC/ATT&CK/CWE)."),
    ]

    title: Annotated[
        str,
        Field(
            min_length=1,
            description="Human-readable title of the KB pattern.",
        ),
    ]

    description: Annotated[
        str,
        Field(
            min_length=1,
            description=(
                "Full description of the threat pattern as stored in the KB. "
                "Passed to generator.py as context for the LLM prompt."
            ),
        ),
    ]

    retrieval_score: Annotated[
        float,
        Field(
            ge=0.0,
            le=1.0,
            description=(
                "Normalized similarity score from FAISS (L2-to-cosine "
                "converted, range [0, 1]).  Used directly as the "
                "retrieval_match_strength input for scorer.py (Section 2.6)."
            ),
        ),
    ]

    asset_id: Annotated[
        str,
        Field(
            min_length=1,
            description=(
                "ID of the asset whose attributes were used as the FAISS "
                "query vector to retrieve this candidate."
            ),
        ),
    ]

    stride_hint: Annotated[
        STRIDECategory | None,
        Field(
            default=None,
            description=(
                "Optional STRIDE classification hint embedded in the KB entry. "
                "When present, generator.py uses this as a prior; when absent, "
                "the LLM infers the STRIDE category from context."
            ),
        ),
    ]

    mitre_tactics: Annotated[
        list[str],
        Field(
            default_factory=list,
            description=(
                "MITRE ATT&CK tactic IDs associated with this pattern "
                "(e.g. ['TA0001', 'TA0003']).  Empty list when the source "
                "is not ATT&CK or no tactic mapping exists."
            ),
        ),
    ]


# ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°
# Ã¢â€Â¬Ã‚Âº 5  ÃŽâ€œÃƒâ€¡ÃƒÂ¶  AttackPath
#         (output of attack_chain.py ÃŽâ€œÃƒâ€¡ÃƒÂ¶ input to generator.py)
# ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°


class AttackPath(BaseModel):
    """A plausible multi-step attack path composed of linked KB candidates.

    attack_chain.py constructs these by topologically ordering KBCandidates
    such that the post-condition of step N is a pre-condition of step N+1.
    This captures realistic kill-chain sequences (e.g. Reconnaissance ÃŽâ€œÃƒÂ¥Ãƒâ€ 
    Initial Access ÃŽâ€œÃƒÂ¥Ãƒâ€  Lateral Movement) rather than treating each threat in
    isolation.

    Design note (Section 2.4 of build plan):
        attack_chain.py must *not* force a chain if no plausible link exists.
        Use ``is_forced=True`` to flag chains where the link is inferred
        rather than pattern-evidenced ÃŽâ€œÃƒâ€¡ÃƒÂ¶ scorer.py will penalise forced chains.

    Generator consumption:
        generator.py receives a list[AttackPath].  Each path produces one
        or more ThreatScenario objects.  The path's ``path_id`` is embedded
        in each scenario's ``tid`` prefix for traceability.
    """

    model_config = ConfigDict(frozen=True)

    path_id: Annotated[
        str,
        Field(
            default_factory=lambda: f"PATH-{uuid.uuid4().hex[:8].upper()}",
            description=(
                "Unique identifier for this attack path within a run.  "
                "Auto-generated; embedded in derived ThreatScenario ``tid``s."
            ),
        ),
    ]

    steps: Annotated[
        list[KBCandidate],
        Field(
            min_length=1,
            description=(
                "Ordered list of KB candidates that form the attack chain, "
                "from earliest (reconnaissance / initial access) to latest "
                "(impact / exfiltration).  Must contain at least one step; "
                "single-step paths are valid when no multi-step chain exists."
            ),
        ),
    ]

    target_asset_ids: Annotated[
        list[str],
        Field(
            min_length=1,
            description=(
                "Asset IDs that this path ultimately threatens.  May span "
                "multiple assets for lateral-movement chains."
            ),
        ),
    ]

    is_forced: Annotated[
        bool,
        Field(
            default=False,
            description=(
                "True when attack_chain.py could not find a pattern-evidenced "
                "link between consecutive steps and inferred the connection.  "
                "Scorer penalises forced chains; Validator emits a warning "
                "check (not a hard failure) when this is True."
            ),
        ),
    ]

    chain_confidence: Annotated[
        float,
        Field(
            ge=0.0,
            le=1.0,
            description=(
                "Aggregate plausibility score for the chain as a whole, "
                "computed by attack_chain.py as the geometric mean of "
                "individual step retrieval_scores, discounted by 0.1 "
                "if is_forced=True.  Used by scorer.py as a secondary "
                "signal for the retrieval_match_strength component."
            ),
        ),
    ]

    reasoning: Annotated[
        str,
        Field(
            default="",
            description=(
                "Free-text explanation of why these steps form a plausible "
                "chain.  Populated by attack_chain.py; passed to generator.py "
                "as chain-level context in the LLM prompt."
            ),
        ),
    ]

    @model_validator(mode="after")
    def _validate_chain_ordering(self) -> AttackPath:
        """Verify there are no duplicate pattern_ids within the same path.

        Duplicate KB patterns in a single chain indicate a logic error in
        attack_chain.py (a loop in the candidate graph), not a legitimate
        multi-step sequence.
        """
        seen: set[str] = set()
        for step in self.steps:
            if step.pattern_id in seen:
                raise ValueError(
                    f"AttackPath '{self.path_id}' contains duplicate "
                    f"pattern_id '{step.pattern_id}'.  Each step in a chain "
                    "must reference a distinct KB pattern."
                )
            seen.add(step.pattern_id)
        return self


# ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°
# Ã¢â€Â¬Ã‚Âº 6  ÃŽâ€œÃƒâ€¡ÃƒÂ¶  ThreatAgent I/O  (Perceive ÃŽâ€œÃƒÂ¥Ãƒâ€  Produce boundary models)
# ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°


class SecurityAttributes(BaseModel):
    """CIA-triad security properties required for this asset per §2.4.

    Distinct from device_config (which captures *what mechanisms the asset has*).
    These fields capture *which security properties the asset needs to maintain*,
    and are used by the Risk Agent's impact scoring (S/F/O/P) in Phase 2.
    """

    model_config = ConfigDict(frozen=True)

    confidentiality: Annotated[
        bool,
        Field(description="Asset requires confidentiality protection (C)."),
    ] = False

    integrity: Annotated[
        bool,
        Field(description="Asset requires integrity protection (I)."),
    ] = False

    availability: Annotated[
        bool,
        Field(description="Asset requires availability protection (A)."),
    ] = False

    authenticity: Annotated[
        bool,
        Field(description="Asset requires authenticity / non-repudiation (Auth)."),
    ] = False


class DFDContext(BaseModel):
    """Data-Flow-Diagram context sourced from Group 1's §2.3.1 output.

    Separates DFD-level context (interfaces, trust zone, flows) from the
    Asset Identification table (§2.4).  retrieval.py reads this to determine
    which KB sources to query and to build the FAISS query vector.
    """

    model_config = ConfigDict(frozen=True)

    interfaces: Annotated[
        list[str],
        Field(
            default_factory=list,
            description=(
                "Communication interfaces of this asset as extracted from the DFD, "
                "e.g. ['BLE 5.0', 'UART', 'OTA update channel']."
            ),
        ),
    ]

    trust_zone: Annotated[
        str,
        Field(
            default="untrusted",
            description=(
                "Trust boundary zone from the DFD, "
                "e.g. 'trusted', 'untrusted', 'DMZ', 'external', 'internal'."
            ),
        ),
    ]

    data_flows: Annotated[
        list[str],
        Field(
            default_factory=list,
            description=(
                "Data flow names that involve this asset as a source or destination, "
                "e.g. ['unlock_command', 'ota_update']."
            ),
        ),
    ]


class AssetModel(BaseModel):
    """A single asset entry aligned with §2.4 Asset Identification table.

    Combines the §2.4 Asset Record fields (asset_id, name, asset_type,
    location, security_attributes, damage_scenario) with a DFDContext block
    sourced from §2.3.1 and Threat-Agent-specific device_config metadata.

    asset_id format follows the §2.4 convention: 'AS-{n}' (e.g. 'AS-1', 'AS-2').
    An explicit id_alias field preserves any internal identifiers for audit.

    Kept deliberately domain-neutral — fields apply equally to a Smart Door
    Lock BLE controller, a medical infusion pump, and a vehicle ECU.
    """

    model_config = ConfigDict(frozen=True)

    # ── §2.4 Asset Identification Table Fields ──────────────────────────────

    asset_id: Annotated[
        str,
        Field(
            min_length=1,
            description=(
                "Unique asset identifier following §2.4 convention: 'AS-{n}', "
                "e.g. 'AS-1', 'AS-2'.  This is the join key for the Traceability "
                "Matrix linking Asset → Threat → Risk → Requirement."
            ),
        ),
    ]

    name: Annotated[
        str,
        Field(min_length=1, description="Human-readable asset name (§2.4)."),
    ]

    asset_type: Annotated[
        str,
        Field(
            default="unspecified",
            description=(
                "Optional internal classification (not in §2.4 baseline). "
                "e.g. 'firmware', 'REST API endpoint', 'BLE peripheral'."
            ),
        ),
    ]

    location: Annotated[
        str,
        Field(
            default="unspecified",
            description=(
                "Physical or logical location of the asset per §2.4, "
                "e.g. 'on-device', 'cloud-hosted', 'edge-gateway', 'internal VLAN'."
            ),
        ),
    ]

    security_attributes: Annotated[
        SecurityAttributes,
        Field(
            default_factory=SecurityAttributes,
            description=(
                "CIA-triad security properties required for this asset per §2.4. "
                "Used by the Risk Agent's impact scoring (S/F/O/P) in Phase 2."
            ),
        ),
    ]

    damage_scenario: Annotated[
        str,
        Field(
            default="",
            description=(
                "Human-readable worst-case damage scenario if this asset is "
                "compromised, per §2.4.  Used by Risk Agent for impact scoring. "
                "e.g. 'Unauthorised physical entry to premises' or "
                "'Incorrect drug dosage causing patient harm'."
            ),
        ),
    ]

    # ── DFD Context (sourced from §2.3.1) ───────────────────────────────────

    dfd_context: Annotated[
        DFDContext,
        Field(
            default_factory=DFDContext,
            description=(
                "Data-Flow-Diagram context for this asset, sourced from §2.3.1. "
                "retrieval.py reads interfaces and trust_zone from here to build "
                "FAISS query vectors and select KB sources."
            ),
        ),
    ]

    # ── Threat-Agent-Specific Technical Metadata ─────────────────────────────

    version: Annotated[
        str,
        Field(
            default="1.0",
            description="Version of this asset record (traceability, §3.4).",
        ),
    ] = "1.0"

    device_config: Annotated[
        dict[str, str],
        Field(
            default_factory=dict,
            description=(
                "Threat-Agent-specific technical device configuration. "
                "Captures *what security mechanisms the asset has* (distinct from "
                "security_attributes which captures *what it needs to protect*). "
                "e.g. {'auth_mechanism': 'PIN-only', 'encryption': 'none', "
                "'firmware_version': '2.3.1'}.  These are the primary "
                "inputs to retrieval.py's FAISS query embedding."
            ),
        ),
    ]

    # ── Backwards-Compat Shims ───────────────────────────────────────────────

    @property
    def interfaces(self) -> list[str]:
        """Convenience accessor — reads from dfd_context.interfaces."""
        return self.dfd_context.interfaces

    @property
    def trust_zone(self) -> str:
        """Convenience accessor — reads from dfd_context.trust_zone."""
        return self.dfd_context.trust_zone


class ThreatAgentInput(BaseModel):
    """Top-level input payload sent by the orchestrator to the Threat Agent.

    After PII redaction (middleware.py), this is passed to perceive().
    Must not assume any domain ÃŽâ€œÃƒâ€¡ÃƒÂ¶ valid for Smart Door Lock, infusion pump,
    vehicle ECU, and any future fixture.
    """

    model_config = ConfigDict(frozen=True)

    run_id: Annotated[
        str,
        Field(
            default_factory=lambda: uuid.uuid4().hex,
            description=(
                "Unique identifier for this Threat Agent invocation.  "
                "Auto-generated if not supplied by the orchestrator.  "
                "Propagated to every ThreatScenario, log entry, and "
                "SCRS write record."
            ),
        ),
    ]

    project_id: Annotated[
        str | None,
        Field(
            default=None,
            description=(
                "Optional product/project identifier. A product can have several use cases "
                "(UC-01, UC-02, ...); each use case is analysed in its own run."
            ),
        ),
    ] = None

    use_case_id: Annotated[
        str | None,
        Field(
            default=None,
            description=(
                "Optional stable use-case identifier from the orchestrator; "
                "derived from the use_case text when absent."
            ),
        ),
    ] = None

    use_case: Annotated[
        str,
        Field(
            min_length=10,
            description=(
                "Natural-language description of the system use case being "
                "threat-modelled.  Minimum 10 chars to reject trivially empty "
                "submissions; the LLM uses this as the top-level context."
            ),
        ),
    ]

    system_model: Annotated[
        str,
        Field(
            min_length=1,
            description=(
                "Serialized system model (DFD/UML description, data flows, "
                "trust boundaries) as a string.  Structured formats (JSON/YAML) "
                "are accepted; perceive() normalises this into NormalizedInput."
            ),
        ),
    ]

    assets: Annotated[
        list[AssetModel],
        Field(
            min_length=1,
            description=(
                "Ordered list of assets within the system model.  "
                "Must contain at least one asset; retrieval.py iterates "
                "over this list to build FAISS query vectors."
            ),
        ),
    ]

    kb_snapshot_version: Annotated[
        str,
        Field(
            default="latest",
            description=(
                "Version or content-hash of the KB snapshot to use.  "
                "Logged verbatim for reproducibility (Section 2.7).  "
                "Use 'latest' to resolve to the current KB at runtime."
            ),
        ),
    ]

    requested_at: Annotated[
        datetime,
        Field(
            default_factory=lambda: datetime.now(UTC),
            description="UTC timestamp when the orchestrator submitted this input.",
        ),
    ]


class NormalizedInput(BaseModel):
    """Output of perceive(): a sanitized, PII-free, structured input.

    perceive() transforms the raw ThreatAgentInput into this model, which
    is the only form that crosses the boundary into plan(), fetch(), etc.
    Any PII field identified during normalization is replaced with a
    ``[REDACTED]`` token before this model is constructed.
    """

    model_config = ConfigDict(frozen=True)

    run_id: str
    use_case: str
    assets: list[AssetModel]
    kb_snapshot_version: str
    system_model_summary: Annotated[
        str,
        Field(
            description=(
                "Structured, normalised summary of the system model.  "
                "perceive() extracts trust boundaries and data flows from "
                "the raw system_model string into this field."
            ),
        ),
    ]
    pii_redacted: Annotated[
        bool,
        Field(
            default=False,
            description="True if at least one PII token was redacted by middleware.",
        ),
    ]


class RetrievalPlan(BaseModel):
    """Output of plan(): specifies which KB categories to query per asset.

    plan() produces this after reasoning about which STRIDE/CAPEC/ATT&CK/CWE
    categories are relevant for each asset's type, interfaces, and trust zone.
    retrieval.py executes the plan against the FAISS index.
    """

    model_config = ConfigDict(frozen=True)

    run_id: str

    queries: Annotated[
        list[dict[str, str | list[str]]],
        Field(
            min_length=1,
            description=(
                "List of retrieval queries, one per asset-category combination.  "
                "Each entry: {'asset_id': str, 'kb_sources': list[KBSource], "
                "'query_text': str}.  retrieval.py iterates this list."
            ),
        ),
    ]

    top_k: Annotated[
        int,
        Field(
            default=10,
            ge=1,
            le=50,
            description=(
                "Maximum number of KB candidates to retrieve per query.  "
                "Default 10; increase for broad assets, decrease for "
                "narrowly-scoped components."
            ),
        ),
    ]


class SCRSWriteResult(BaseModel):
    """Outcome of writing approved scenarios to the Shared Reasoning State.

    Returned by produce() after state_manager.py commits the approved
    ThreatScenario list to the SCRS.  The Risk Agent reads the SCRS
    using the ``scrs_entry_id`` to locate this run's threat output.
    """

    model_config = ConfigDict(frozen=True)

    run_id: str

    scrs_entry_id: Annotated[
        str,
        Field(
            min_length=1,
            description=(
                "Stable SCRS key under which the approved ThreatScenario list "
                "is stored.  Communicated to the Risk Agent by the orchestrator."
            ),
        ),
    ]

    scenario_count: Annotated[
        int,
        Field(
            ge=0,
            description="Number of approved ThreatScenario objects written to SCRS.",
        ),
    ]

    written_at: Annotated[
        datetime,
        Field(
            default_factory=lambda: datetime.now(UTC),
            description="UTC timestamp of the SCRS write operation.",
        ),
    ]

    audit_log_ref: Annotated[
        str,
        Field(
            description=(
                "Reference to the structured audit log entry for this write, "
                "formatted as '<log_file>:<line_offset>' or a log-store ID."
            ),
        ),
    ]


# ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°
# Ã¢â€Â¬Ã‚Âº 7  ÃŽâ€œÃƒâ€¡ÃƒÂ¶  Module-level exports
# ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°ÃŽâ€œÃƒÂ²Ãƒâ€°

# Exports are listed alphabetically (ruff RUF022 requires a flat sorted __all__).
# Logical groupings: Enumerations â†’ Core models â†’ I/O boundary models â†’ Type aliases.
__all__: list[str] = [
    "AssetModel",
    "AttackPath",
    "ConfidenceScore",
    "EvidenceChain",
    "FailedCheck",
    "KBCandidate",
    "KBSource",
    "NormalizedInput",
    "RetrievalPlan",
    "SCRSWriteResult",
    "STRIDECategory",
    "ThreatAgentInput",
    "ThreatScenario",
    "ThreatStatus",
    "ValidationResult",
]

